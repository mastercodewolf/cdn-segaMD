-NOTE
DO NOT Link the download link (link this video and credit me) when showcasing this hack.
DO NOT Steal this hack
DO NOT Steal the sprites
DO NOT Repost the hack on an online website without my permission
[Looking at you ssega.com]

-INSTALL INSTRUCTIONS
-Extract the Sonic_2_The_Alternate_Sprites_V2.bin file.
-Open it using an emulator of your choice (I use the Kega Fusion Emulator on PC and RetroMD on Android)
-Have fun!