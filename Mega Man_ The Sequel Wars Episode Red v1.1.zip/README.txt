============================================
MEGA MAN: THE SEQUEL WARS - EPISODE RED V1.1
      BY WOODFROG AND TEAM SEQUEL WARS
============================================
Thank you for downloading the game! We hope you'll have a good time with it and enjoy the 16-bit upgrade on the already great original.

Note that EPISODE RED contains the Mega Man 4 remake only. 5 and 6 will arrive later.


================
EPILEPSY WARNING
================
This game contains various instances of flashing lights.
If you have any issues of the sort, make absolutely sure the "DIMINISHED FLASHING" option is toggled ON in the settings.
Even with the setting enabled, it is still heavily recommended that you take care while playing the game. Do not sit close to the screen, take frequent breaks and watch out for any possible symptoms.


===========
HOW TO PLAY
===========
This game is a homebrew project for the Sega Genesis/Mega Drive game console. The download provides you with a ROM image made specifically for use with said console.

===REAL HARDWARE===
If you own a real Sega Genesis/Mega Drive game console, you will need a flash cart, a special cartridge that lets you store ROMs on it so you can load them into your system. Refer to the instructions of your flash cart on how to do this.
This game has been tested on various models of both NTSC and PAL systems, and it should work on all variations.
This game relies on some strict timings for loading graphics. If you experience flickering or some corrupted sprites, it might get fixed by reflashing the ROM or formatting your SD card.
This game uses SRAM to save your progress and settings. While most flash carts have SRAM support, the game should also function without it, and a password system is provided for this purpose.
The password system is the same one as in Mega Man 4. All passwords that work in the original MM4 should also work here. However, this game can also provide additional passwords that will save progress in the fortress stages. These will contain white balls - press FIRE to input them.

===PC/EMULATION===
If you do not own the real console but want to play the game anyway, you can use an emulator, a program that lets you play games for the console on other systems.
Our recommendation of choice is Blast'Em or Bizhawk (using the Genplus-gx core). The game should work on most emulators, but please note that it might fail on some older, less accurate emulators.


========
CONTROLS
========
There are two control schemes:
"DEFAULT" - A = Shoot, B = Jump, C = Slide
"WILY WARS" - A = Pause, B = Shoot, C = Jump
On top of that, this game supports the 6 button pad for additional functions:
X = Built-in autofire (can fire at both human and "true turbo" speeds)
Y/Z = Quick weapon switch


===============
ADDITIONAL TIPS
===============
-While she uses a melee broom, Roll can still charge up a big ranged shot.

-You can hold B on the Stage Select to go back to the Title Screen. (THIS WILL NOT SAVE YOUR GAME)

-You can prolong the Flash Stopper's duration by sliding.

-Dr. Wily has created many diabolical traps which take advantage of Mega Man's ultra advanced arsenal. Watch out for traps that Mega Man cannot escape. If you fall into the wrong trap, you might have to reset the game (by pressing the RESET button) and start again at the beginning of the stage you were last in. Avoid using Rush or other utilities near corners and ceilings.

-Here are the settings toggled by the preset chosen on first boot:
NEW BOSS INTROS, PURIST VFX, MUSIC STYLE, NEW BOSS EXPLOSIONS, NEW STAGE INTROS, BOSS CORRIDOR MUSIC, LIFE COUNTER.

