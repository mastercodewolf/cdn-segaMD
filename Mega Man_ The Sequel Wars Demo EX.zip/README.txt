MEGA MAN: THE SEQUEL WARS - EPISODE RED DEMO (EX UPDATE)
BY SOKZAJELO AND THE SEQUEL WARS TEAM

1.01 HOTFIX - Fixed an issue where Pharaoh Shot would despawn if held while high up on the screen.
EX UPDATE - Skull Man EX stage added + a bunch of fixes and additions

========
INTRO
========
Welcome! Thank you for downloading this demo. It contains 4 remade stages from the original Mega Man 4, plus a whole new re-imagined Skull Man stage (the final game will have this for each stage!).
To keep up with the news about the game, check out:

https://twitter.com/MMSequelWars (Project twitter)
https://www.youtube.com/channel/UCh6puDO3hd_Tz_zCiDoD2lQ (my YT channel where I regularly drop updates)
http://www.sprites-inc.co.uk/thread-2880.html (the game's thread on sprites-inc)


The game is provided as a Sega Mega Drive ROM. To play it, you have to:
1) Own an original Sega Genesis and an appropriate flashcart.
2) Use a Sega Genesis emulator.
If you can do 1), I don't need to give you instructions :P But if you are opting for 2), the emulator I recommend is BlastEm, currently the most accurate Genesis emulator out there as of writing. However, pretty much any emulator should do. There's a lot of them for various platforms, so if you want you can even play this on a Wii or 3DS! Google is your best friend.

The game has been through a lot of testing, but the nature of working with such old hardware means that bugs of all kinds are bound to crop up. If you come across any issues, feel free to report it to me on Discord (add SokZaJelo#8305)!

=========
SETTINGS
=========
Be sure to check out the settings menu! If you're already used to playing Wily Wars, set the control scheme to Type B!

-Control Scheme | TYPE A, TYPE B
Select between 2 control schemes. Type A is the default, with A to shoot, B to jump and C to slide.
Type B is the scheme used in Wily Wars: A to pause, B to shoot and C to jump.
Additionally, in type B you can jump out of a slide even if down is still held, since it works this way in Wily Wars so your muscle memory doesn't screw you over.
Both schemes support the 6 BUTTON CONTROLLER as of the update! Hold X to auto-fire (at a human pace rather than the game-breaking pace of turbo buttons), and Y/Z to switch weapons without having to open the menu. Press Y and Z at the same time to switch to the buster.

-Simplified Backgrounds | OFF, ON
If enabled, some backgrounds will lose visual detail. Select this if you don't like some of the busier backgrounds, or if you want to reduce slowdown in some areas.

-Screen Transition Speed | SLOW, MEDIUM, FAST
This affects the speed at which the camera will move when moving between screens.
Slow matches the original MM4.
Medium is the default and matches a typical Mega Man game.
Fast is self-explanatory.

-Purist VFX | OFF, ON
If enabled, some effects added in this game that are not present in Wily Wars are removed. These include:
-enemy wreckage flying off when destroyed
-muzzle flash when firing the buster
-boss intro animations (they will instead just jump in from above like in the original)

-Screen Shake | NORMAL, LIGHT, DISABLED
Change the way the screen shaking effect works or disable it entirely.
Light makes the screen shaking never increase in intensity.

-Music | MODERN, CLASSIC
Change between 2 music styles.
'Modern' ignores the limits set by Wily Wars.
'Classic' is made to sound like the original Wily Wars.

Difficulty | EASY, NORMAL, HARD
Easy reduces the damage you take from heavy threats and gives enemies more chance to spawn pickups when destroyed. It also makes spikes do damage instead of insta-kill.
Hard increases all damage you take from all sources and decreases the chance of pickups spawning.

Infinite Lives | OFF, ON
If enabled, you will never lose a life upon death and can't game over.

========
CREDITS
========
SokZaJelo - Project Lead, code/design/sound/art/etc.
Nathan Silver - Additional Art
Ryla - Additional Art
(Former) Blonemon X - Additional Art
Armored-Struggle-Wagon - Music
forple - Music
Teuthida - Music
Camping6464 - Lead Tester, Level Designer
Ferman Gürleroğlu - Level Designer
Fox in Yellow Socks - Lead Tester
GlitchyTSP - Tester
Lion Sum - Hardware Tester
Sfan - Hardware Tester
kspiff - Hardware Tester
Alex Parr - Hardware Tester
SPECIAL THANKS TO:
Capcom for the original game
Minakuchi Engineering for the original Wily Wars, as well as the MMGB games which served as a basis for some assets
The anon from /mmg/ who suggested the project name. Thanks dude
Bongwater-Bandit for previous work on a WW project which served as a basis for some assets (with permission)