Modern Sonic sprites by Cylent Nite.
Classic Generations Sonic and ROM Hack by me, PotterAndMatrixFan.



Please don't upload this anywhere else without my permission.
If you didn't get this rar off from my release video on Youtube.com, it's stolen.

