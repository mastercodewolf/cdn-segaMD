MEGA MAN: THE SEQUEL WARS - EPISODE RED DEMO P1 1.01
BY SOKZAJELO AND THE SEQUEL WARS TEAM

1.01 HOTFIX - Fixed an issue where Pharaoh Shot would despawn if held while high up on the screen.

========
INTRO
========
Welcome! Thank you for downloading this demo. It contains 4 remade stages from the original Mega Man 4.
Due to time constraints, the demo does not yet contain the planned EX stage. It's being kept for some additional brushing up, and will be released in an update for the demo in a week.
To keep up with the news about the game, check out:

https://www.youtube.com/channel/UCh6puDO3hd_Tz_zCiDoD2lQ (my YT channel where I regularly drop updates)
http://www.sprites-inc.co.uk/thread-2880.html (the game's thread on sprites-inc)

The game is provided as a Sega Mega Drive ROM. To play it, you have to:
1) Own an original Sega Genesis and an appropriate flashcart.
2) Use a Sega Genesis emulator.
If you can do 1), I don't need to give you instructions :P But if you are opting for 2), the emulator I recommend is BlastEm, currently the most accurate Genesis emulator out there as of writing. However, pretty much any emulator should do. There's a lot of them for various platforms, so if you want you can even play this on a Wii or 3DS! Google is your best friend.

Be sure to check out the settings menu! If you're already used to playing Wily Wars, set the control scheme to Type B!

The game has been through a lot of testing, but the nature of working with such old hardware means that bugs of all kinds are bound to crop up. If you come across any issues, feel free to report it to me on Discord (add SokZaJelo#8305)!

========
CREDITS
========
SokZaJelo - Project Lead, code/design/sound/art/etc.
Nathan Silver - Additional Sprite Art (Bright Man)
Blonemon X - Additional Sprite Art (Toad Man, Dust Man, EX Mode enemies)
Camping6464 - Lead Tester, Level Designer
GlitchyTSP - Tester
Ryla - Hardware Tester
Lion Sum - Hardware Tester
Sfan - Hardware Tester
kspiff - Hardware Tester
Alex Parr - Hardware Tester
SPECIAL THANKS TO:
Capcom for the original game
Minakuchi Engineering for the original Wily Wars, as well as the MMGB games which served as a basis for some assets
The anon from /mmg/ who suggested the project name. Thanks dude
Bongwater-Bandit for previous work on a WW project which served as a basis for some assets (with permission)