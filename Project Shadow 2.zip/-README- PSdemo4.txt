------------------------------------------------------------------------
  Project Shadow 2   DEMO 4              by JohnnyUK of Shadowsoft-Games
------------------------------------------------------------------------
                                            | www.shadowsoft-games.com |
                                            |__________________________|

VERSION 1.00
(Believe it or not, this was unintentional)

 Contents:
------------------------
1. Introduction
2. Changes
3.'Installation'
4. Known issues
5. >!BONUS!<
6. Credits
------------------------
 1. Introduction
------------------------

Project Shadow 2 is, first off, not in fact a sequel. The 2 simply
signifies that it is for Sonic The Hedgehog 2. The aim of this project
is to make the character 'Shadow' playable, with a chao sidekick, in 
new levels in sonic 2.

As far as I know, there aren't any serious level design errors, and the 
testers have confirmed this. PLEASE report any level design flaws you 
encounter, be it a 'broken' tile (level tile that looks wrong), solidty 
errors or generally just places you think would be better approached
in a different way. I am dedicated to making this hack completely
bug free and easy on the eyes. Please help me achieve that.

------------------------
 2. Changes
------------------------

Since demo3 and the public demo after it, a ton has changed. First
of all, we have the new art - almost all references to Sonic are now
Shadow, and same with Tails/Chao. Second, I've added the monitor
graphics - now they look much more like the Adventure Series (Especially
the 10-ring icon).

On the technical side of things, the bonus level is not slap bang in 
the middle of Ivy Lakes anymore - infact, you have to work for it.
Collect 200 rings and enter it through any starpost. Not only will
it give you the bonus stage, it'll skip to the next level. 

Level design has changed in many areas - the most blatent of which
being two brand new levels to play with, as well as more edited tile
art and MANY fixes/new routes and changes to older levels - too many 
to list, anyway. I've also put a lot of time into 'level transitions',
that is making the end of an act look like the beginning of the next,
including Zone Transitions, involving quick tile art applied to the end
of a zone to represent the next. I felt this would add a certain amount
of continuity to the mix.
 
------------------------
 3. Installation
------------------------

There's no IPS junk or such, just play the ROM in a Genesis Emulator.
For this demo, no IPS will be available - it's simply too irritating =P

------------------------
 4. Known issues
------------------------
-Title screen not finished.

-any level beyond the 5th one (not including the bonus stage) is NOT
 complete so please dont mention any of them as bugs - I know most of
 them are screwed - I also know how to fix them, but they're not done =P

-The Chao is NOT complete. needs a better 'flying' anim, and 'walking'
 anim. Not had the time to do it.
------------------------
 5. Bonus!
------------------------

Just like the last demo, there's a secret download for you to
get your hands on - but trust me, its a little harder than
just getting to the end this time! Now you have to find the 
password. Its in BLOCK CAPITALS. Here are your clues:

Carved in a wall, in a cave somewhere in Ivy Lakes two.
You have ONE chance per life to get it.
Its accompanied by a group of powerups
It cannot be seen by 'looking up' or 'looking down' from below or above.

Once you have the password, go here:

http://www.shadowsoft-games.com/PSBONUS/
(NOTE: This link is now dead--use http://info.sonicretro.org/psbonus/psbonus.php)

play the demo, copy the URL into your address bar in your browser 
and you'll be asked to log in. The username is simply 'shadow'.

The full URL will be revealed on the shadowsoft-games' news page 
(http://www.shadowsoft-games.com/?page=news.php) 1 week after 
release if you dont fully understand this.

have fun!

------------------------
 6. credits 
------------------------

Project leader:            JohnnyUK
Coding:                    Ultima + DRX
Compressed Art Help:       Dr. Eggfan
Level bugging:             Shadowsoft Testers
Chao Sprites:              From Sonic Advance 2, ripped and edited by Neo, 
                           additional edits by JohnnyUK

Special Thanks:

*Ultima - Probably would've packed my bags and switched out the light
         if it weren't for him =P (not to mention the rediculous 
         amount of feedback/constructive critisism I get off him)

*Drx - ASM coding god.

*KojiChao - started me on hex. What more can I say?

*Stealth - SonED makes level editing about 40 times easier than hex.

*Nik + Overlord - Constant support and general friends.

*Anyone who plays this hack - hey, I needed a cheesy ending =P


Finally, to coin a phrase - Enjoy Chilled =P

--JOHNNYUK